import time
from colorama import Fore, Back, Style
import requests
import json
import os
try:
   from pystyle import Colors, Colorate
except:
    os.system("pip install pystyle")
try:
   from rgbprint import gradient_print, Color, rgbprint
except:
    os.system("pip install rgbprint")

title = ("""
     
                              ▓▓██░░    ▓▓██████████████    ██████            
                            ██▒▒  ░░██████████████████████████    ██████        
                          ██  ▒▒██░░  ████████████████████░░▒▒██▒▒  ▓▓████      
                        ██  ██       ████████      ████████     ████  ▒▒████░░  
                      ▒▒            ████████        ████████      ████    ██████
                    ░░░░            ████████        ████████        ████  ░░████
                   ░░               ████████        ████████          ████    ██
                                     ▒▒████████████████████          ██████    
                                      ████████████████████          ░░██████    
                      ░░                ████████████████          ░░██▒▒████    
                          ░░              ▒▒████████▒▒          ████            
                            ▒▒▒▒░░                          ▒▒██                
                                  ░░▒▒██                ▓▓██                                                                                                                                                                                                    
                                                                                                              
                            made by amDise#4048 .gg/E4bz45gMtp
                            themes update credits: xolo                                                                                                                                                                                                                           
""")
start_time = time.monotonic()
def _print_stats(self) -> None:
        elapsed = time.monotonic() - start_time
        elapsed_str = time.strftime("%H:%M:%S", time.gmtime(elapsed))
        gradient_print(title, start_color=Color.orange, end_color=Color.red)
        gradient_print(f" v {self.version}       ", start_color=Color.firebrick, end_color=Color.maroon)
        print(Style.BRIGHT + f"                                       ")
        print(Fore.RED + " >" + f" {Color.dark_red}Runtime: {Color.firebrick}{Style.BRIGHT}{elapsed_str}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + " >" + f" {Color.dark_red}Better Autosearch: {Color.firebrick}{Style.BRIGHT}{self.connected}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + " >" + f" {Color.dark_red}Status: {Color.firebrick}{Style.BRIGHT}{self.task}{Color.firebrick}")
        print(Style.BRIGHT + f"                                       ")
        print(Style.BRIGHT + f"                                       ")
        print(Fore.RED + " >" + f" {Color.dark_red}V1 THREAD:{Color.firebrick}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Enabled: {Color.firebrick}{Style.BRIGHT}{self.v1thread}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Buys: {Color.firebrick}{Style.BRIGHT}{self.buys}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Errors/Ratelimits: {Color.firebrick}{Style.BRIGHT}{self.errors}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Price Checks: {Color.firebrick}{Style.BRIGHT}{self.checks}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Speed: {Color.firebrick}{Style.BRIGHT}{self.last_time}{Fore.WHITE}{Style.BRIGHT}")
        print(Style.BRIGHT + f"                                        ")
        print(Fore.RED + " >" + f" {Color.dark_red}V2 THREAD:{Color.firebrick}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Enabled: {Color.firebrick}{Style.BRIGHT}{self.v2thread}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Buys: {Color.firebrick}{Style.BRIGHT}{self.v2buys}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Errors/Ratelimits: {Color.firebrick}{Style.BRIGHT}{self.v2errors}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Price Checks: {Color.firebrick}{Style.BRIGHT}{self.v2checks}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + "   >" + f" {Color.dark_red}Speed: {Color.firebrick}{Style.BRIGHT}{self.v2last_time}{Fore.WHITE}{Style.BRIGHT}")
        print(Style.BRIGHT + f"                                        ")
        print(Fore.RED + " >" + f" {Color.dark_red}Accounts: {Color.firebrick}{Style.BRIGHT}{self.accountsAmount}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + " >" + f" {Color.dark_red}Webhook: {Color.firebrick}{Style.BRIGHT}{self.webhookEnabled}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + " >" + f" {Color.dark_red}Total Proxies: {Color.firebrick}{Style.BRIGHT}{len(self.proxy_list)}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + " >" + f" {Color.dark_red}Proxy Enabled: {Color.firebrick}{Style.BRIGHT}{self.proxy_enabled}{Fore.WHITE}{Style.BRIGHT}")
        print(Style.BRIGHT + f"                                        ")
        print(Fore.RED + " >" + f" {Color.dark_red}Loaded Items: {Color.firebrick}{Style.BRIGHT}{len(self.items)}{Color.white}{Fore.WHITE}{Style.BRIGHT}")
        print(Fore.RED + " >" + f" {Color.dark_red}Id/s: {Color.firebrick}{Style.BRIGHT}{', '.join(map(str, self.items))}{Color.white}{Fore.WHITE}{Style.BRIGHT}")
        print(Style.BRIGHT + f"                                        ")
